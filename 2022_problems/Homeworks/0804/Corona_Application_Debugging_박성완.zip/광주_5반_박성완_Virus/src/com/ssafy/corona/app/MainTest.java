package com.ssafy.corona.app;

import java.util.*;
import com.ssafy.corona.virus.*;

public class MainTest {
	public static void main(String[] args) {
	

		// 10.질병관리 문제 //
		//
		//	아래 11~13번 주석을 해제하여
		//	"정상 출력 예" 와 같이 출력될 수 있도록 
		//	코드들을 디버깅 하세요!
		//
		System.out.println("10.질병관리(코로나,메르스) =================================");
		VirusMgr vmgr=new VirusMgrImpl();
		System.out.println();		
		
 //<- 주석 해제 후 작성 : start ////////////////////////////////
		System.out.println("11.코로나19 등록");
		// 정상 출력 예: 
		// 11.코로나19 등록
		// 코로나19: 등록된 바이러스입니다.
		try {
			vmgr.add(new Mers(  "메르스15", 2, 1.5));
			vmgr.add(new Corona("코로나19", 3, 2));
			vmgr.add(new Corona("코로나19", 2, 2));
		} catch (DuplicatedException e) {
			System.out.println(e.getMessage());
		}
		System.out.println();
		
		
		System.out.println("12.바이러스 전체검색");
		// 정상 출력 예: 
		// 12.바이러스 전체검색
		// 메르스15	2	1.5
		// 코로나19	3	2
		Virus[] virus=vmgr.search();
		for(Virus v:virus) {
			System.out.println(v);
		}
		System.out.println();
		
		
		System.out.println("13.코로나15 조회");
		// 정상 출력 예: 
		// 13.코로나15 조회
		// 코로나15: 미등록 바이러스입니다.
		try {
			Virus v=vmgr.search("코로나15");
			System.out.println(v);
		} catch (NotFoundException e) {
			System.out.println(e.getMessage());
		}
		System.out.println();
 //<- 주석 해제 후 작성 : end /////////////////////////////////
		
		// 객체 추가
		try {
		vmgr.add(new Mers(  "메르스16", 2, 1.5));
		vmgr.add(new Mers(  "메르스17", 3, 2.5));
		vmgr.add(new Mers(  "메르스18", 4, 3.5));
		vmgr.add(new Corona("코로나20", 4, 3));
		vmgr.add(new Corona("코로나21", 3, 2));
		} catch (DuplicatedException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println();
		System.out.println("====메르스 전체 검색===");
		Virus[] mm = vmgr.searchMers();
		for(Virus v : mm)System.out.println(v.toString());
		
		System.out.println();
		System.out.println("====코로나 전체 검색===");
		Virus[] cc = vmgr.searchCorona();
		for(Virus v : cc)System.out.println(v.toString());
		
		System.out.println();
		System.out.println("=== 객체 정렬 추가 : Comparable .vs. Comparator ===");
		System.out.println("24.바이러스 전체 검색 : 등급이 낮은 순서대로 (올림정렬)조회 : Virus 정렬 구현");
		List<Virus> lis = vmgr.searchList();
		lis.sort((m1,m2)->m1.getLevel()-m2.getLevel());
		lis.forEach(m-> System.out.println(m.toString()));
		
		System.out.println();
		System.out.println("25.코로나 전체 검색: 이름 순서대로(올림정렬)조회: Anonymous inner class 정렬 구현");
		List<Virus> corona = Arrays.asList(vmgr.searchCorona());
		corona.sort((m1,m2)->m1.getName().compareTo(m2.getName()));
		corona.forEach((m)-> System.out.println(m.toString()));
		
		System.out.println();
		System.out.println("26.바이러스 전체 검색 : 배열에 저장된 바이러스 객체들을 List<virus> 자료 저장 구조 변환");
		List<Virus> list = vmgr.searchList();
		list.forEach((m)-> System.out.println(m.toString()));
	
		
		System.out.println();
		System.out.println("27.List<Virus> 전체 조회 후 바이러스 등급이 낮은 순서대로 (올림정렬) 조회");
		list.sort((m1,m2)->m1.getLevel() - m2.getLevel());
		list.forEach((m)->System.out.println(m.toString()));		
		
		System.out.println();
		System.out.println("28.List<Virus> 전체 조회 후 바이러스 이름(내림) 순서대로 정렬 조회");
		list.sort((m1,m2)->m2.getName().compareTo(m1.getName()));
		list.forEach((m)->System.out.println(m.toString()));	

	}
}
