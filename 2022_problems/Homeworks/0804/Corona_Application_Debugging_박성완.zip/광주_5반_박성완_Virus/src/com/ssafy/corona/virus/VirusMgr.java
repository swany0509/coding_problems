package com.ssafy.corona.virus;

import java.util.List;

public interface VirusMgr {
	void add(Virus v) throws DuplicatedException;
	Virus[] search();
	Virus search(String name) throws NotFoundException;
	
	// 메르스 전체 조회
	Virus[] searchMers();
	// 코로나 전체 조회
	Virus[] searchCorona();
	// 바이러스 배열 자료 저장 구조를 Collection List<Virus> 자료 저장 주고 변환 조회
	List<Virus> searchList();
}